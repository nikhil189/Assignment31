package accadglidassignment;

public class Test {
	static{
		print(10);
		}
		static void print (int x) {
		System.out.println (x);
		System.exit(0);
		}
}
